import { style } from '@vanilla-extract/css';

export const flex = style({
  display: 'flex',
  flex: 1
});
