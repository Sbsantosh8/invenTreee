import * as classes from '../../main.css';

export function Footer() {
  return (
    <div className={classes.layoutFooter}>
      {
        // Placeholder for footer links
      }
    </div>
  );
}
