export const CHART_COLORS: string[] = [
  'blue',
  'teal',
  'lime',
  'yellow',
  'grape',
  'red',
  'orange',
  'green',
  'indigo',
  'pink'
];
