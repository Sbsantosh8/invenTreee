import { IconAlertCircle } from '@tabler/icons-react';

export function UnavailableIndicator() {
  return <IconAlertCircle size={18} color='red' />;
}
